#ifndef MYFIGURES_H
#define MYFIGURES_H

#include <QWidget>
#include <QColor>
#include <QToolTip>
#include <QRect>
#include <QMenu>
#include "figure.h"
#include <iostream>
#include <QDrag>
#include <QMimeData>

class MyFigures : public QWidget
{
    Q_OBJECT
public:
    explicit MyFigures(QWidget *parent = nullptr);
    ~MyFigures();

    void setFigures(std::list<std::unique_ptr<Figure>>&& figs) {
        _figs = std::move(figs);
    }

protected:
    void paintEvent(QPaintEvent *event) override;

    void mouseMoveEvent(QMouseEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;

private:
    std::list<std::unique_ptr<Figure>> _figs;
    QPoint last_pos;

private slots:
    void DeleteFigure(Figure& f);
};

#endif // MYFIGURES_H
