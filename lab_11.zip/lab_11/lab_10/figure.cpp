#include "figure.h"

void Circle::paint(QPainter &painter) {
    painter.drawEllipse(_ref.x() - diametr/2, _ref.y() - diametr/2, diametr, diametr);
}

bool Circle::CursorInFigure(const QPoint& pos_mouse) {
    if (std::pow(diametr/2.0, 2) >= std::pow(pos_mouse.x() - _ref.x(), 2) + std::pow(pos_mouse.y() - _ref.y(), 2))
        return true;
    return false;
}

QString Circle::Information() {
    QString mess = "Circle""\nDiameter: " + QString::number(this->diametr); // + "\nCenter: "+QString::number(this.)
    return QString(mess);
}

void Circle::MoveFigure(QPoint p) {
    _ref += p;
}


QString printPoint_ (int N, QPolygon poly) {
    QString message = "\n";
    for (int i = 0; i < N; i++) {
        message = message + "( "+QString::number(poly.point(i).x())+" ; "+QString::number(poly.point(i).y())+" )\n";
    }
    return message;
}
