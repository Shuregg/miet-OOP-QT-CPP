#include <QDebug>

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "figure.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    std::list<std::unique_ptr<Figure>> figs;

    figs.push_back(std::make_unique<Triangle>(std::array{QPoint(400, 100), QPoint(300, 300), QPoint(350, 350)}));

    figs.push_back(std::make_unique<Rectangle>(std::array{QPoint(200, 115), QPoint(100, 300), QPoint(250, 300), QPoint(250, 115)}));
    figs.push_back(std::make_unique<Rectangle>(std::array{QPoint(500, 100), QPoint(600, 100), QPoint(500, 200), QPoint(600, 200)}));

    figs.push_back(std::make_unique<Circle>(QPoint(357, 456), 78));
    figs.push_back(std::make_unique<Circle>(QPoint(557, 356), 120));

    ui->widget->setFigures(std::move(figs));
}

MainWindow::~MainWindow()
{
}

