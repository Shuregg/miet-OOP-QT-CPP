#ifndef FIGURE_H
#define FIGURE_H

#include <array>
#include <iostream>
#include <algorithm>
#include <QPoint>
#include <QPainter>
#include <QPolygon>
#include <cmath>
#include <QList>
#include <QString>
#include <string>

QString printPoint_ (int N, QPolygon poly);

class Figure
{
public:
    Figure(const QPoint &ref)
        : _ref(ref)
    {
    }
    virtual void paint(QPainter &painter) = 0;
    virtual bool CursorInFigure(const QPoint& pos_mouse) = 0;
    virtual QString Information() = 0;
    virtual void MoveFigure(QPoint p) = 0;
    QPoint _ref;
    bool InFigure = false;
};

template<size_t N>
class Polygon : public Figure {
public:
    Polygon(const std::array<QPoint, N>& verts)
        : Figure(verts[0])
    {

        QVector<QPoint> _verts;
        for (auto v : verts) {
            _verts.push_back(v);
        }
        _polygon = QPolygon(_verts);
    }

    void paint(QPainter &painter) override {
        painter.drawPolygon(_polygon);
    }

    bool CursorInFigure(const QPoint& pos_mouse) override {
        return _polygon.containsPoint(pos_mouse, Qt::WindingFill);
    }

    QString Information() override {
        QString mess;
        switch (N) {
        case(1): {
            mess = "Point"; // + printPoint(N,_polygon);s
            //return mess;
            break;
        }
        case(2): {
            mess = "Line";// + printPoint(N, _polygon);
            //return mess;
            break;
        }
        case(3): {
            mess = "Triangle";// + printPoint(N, _polygon);
            //return mess;
            break;
        }
        case(4): {
            mess = "Rectangle";// + printPoint(N, _polygon);
            //return mess;
            break;
        }
        default: {
            mess = "Polygon";
            break;
        }
        }

        QString dop = printPoint_(N, _polygon);
        mess = mess + dop;
        return mess;
    }

    void MoveFigure(QPoint p) override {
       _polygon.translate(p);
    }

private:
    QPolygon _polygon;
};

typedef Polygon<3> Triangle;

typedef Polygon<4> Rectangle;

class Circle : public Figure{
public:
    Circle(QPoint center, int d)
        : Figure(center)
        , diametr(d)
    {
    }

//    int getCenterPos () {

//    }
    void paint(QPainter &painter) override ;

    bool CursorInFigure(const QPoint& pos_mouse) override ;

    QString Information() override ;

    void MoveFigure(QPoint p) override ;

private:
    int diametr;
};

#endif // FIGURE_H
