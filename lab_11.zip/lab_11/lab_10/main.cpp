#include <iostream>
#include <algorithm>
#include <cmath>

#include "mainwindow.h"

#include <QApplication>

bool is_even(int x) { return x % 2 == 0; }

int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();

    return 0;
}
