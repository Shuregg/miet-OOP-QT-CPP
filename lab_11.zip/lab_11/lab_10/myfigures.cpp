#include <QPainter>
#include <QMouseEvent>
#include <iterator>
#include <algorithm>
#include "myfigures.h"

MyFigures::MyFigures(QWidget *parent) : QWidget(parent)
{
    setMouseTracking(true);
}

MyFigures::~MyFigures()
{

}
std::vector<QColor> randomColor() {
    QPen pen;
    QBrush brush(Qt::gray);
    pen.setWidth(2);
    int r = rand() % 4;
    std::vector<QColor> colors;

    switch (r) {
    case 0: {
        colors.push_back(Qt::magenta);
        colors.push_back(Qt::darkMagenta);
        break;
    }
    case 1: {
        colors.push_back(Qt::yellow);
        colors.push_back(Qt::darkYellow);
        break;
    }
    case 2: {
        colors.push_back(Qt::cyan);
        colors.push_back(Qt::darkCyan);
        break;
    }
    case 3: {
        colors.push_back(Qt::red);
        colors.push_back(Qt::darkRed);
        break;
    }
    default: {
        colors.push_back(Qt::green);
        colors.push_back(Qt::darkGreen);
        break;
    }
    }
}
void MyFigures::DeleteFigure(Figure& f)
{
    auto it = find_if(_figs.begin(), _figs.end(), [&](std::unique_ptr<Figure>& ptr_f){
        return ptr_f.get() == &f;
    });
    _figs.erase(it);
    update();
}

void MyFigures::mousePressEvent(QMouseEvent *event)
{
    QPoint pos_mouse = event->pos();
    QPoint globalCoursorPos = event->globalPos();
    for (auto &f : _figs){
        if (f->CursorInFigure(pos_mouse) && event->button() == Qt::LeftButton)
            QToolTip::showText(globalCoursorPos, f->Information());
        if (f->CursorInFigure(pos_mouse) && event->button() == Qt::RightButton) {
            std::unique_ptr<QMenu> FigureMenu = std::make_unique<QMenu>();
            std::unique_ptr<QAction> del = std::make_unique<QAction>("Delete", this);
            connect(del.get(), &QAction::triggered, [&](){
                this->DeleteFigure(*(f.get()));
            });
            FigureMenu->addAction(del.get());
            FigureMenu->exec(globalCoursorPos);
        }
    }
}

void MyFigures::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QPen pen(Qt::black);
    pen.setWidth(2);
    painter.setPen(pen);

    for (auto &f : _figs){

        if (f->InFigure){
            QBrush brush(Qt::darkMagenta);
            painter.setBrush(brush);
        } else {
            QBrush brush(Qt::magenta);
            painter.setBrush(brush);
        }
        f->paint(painter);
    }

}


void MyFigures::mouseMoveEvent(QMouseEvent *event)
{
    QPen pen;
    QBrush brush(Qt::black);
    for (auto &f : _figs) {
        brush.setColor(Qt::magenta);
        pen.setColor(Qt::darkMagenta);
        QPoint mouse_pos = event->pos();

        if(f->CursorInFigure(mouse_pos)){
            f->InFigure = true;
            update();
        } else {
            f->InFigure = false;
            update();
        }
        if (f->CursorInFigure(mouse_pos) && (event->buttons() & Qt::LeftButton)) {
            QPoint delta_point = mouse_pos - last_pos;
            f->MoveFigure(delta_point);
            update();
        }
    }
    last_pos = event->pos();
}
