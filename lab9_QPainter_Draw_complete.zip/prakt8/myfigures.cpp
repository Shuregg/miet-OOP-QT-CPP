#include <QPainter>

#include "myfigures.h"

MyFigures::MyFigures(QWidget *parent) : QWidget(parent)
{

}

MyFigures::~MyFigures()
{
    for(auto i : _figs) {
        delete &i;
    }
}

void MyFigures::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);

    QPen pen(Qt::magenta);
    pen.setWidth(3);

//    int r = rand() % 4;
//    switch (r) {
//    case: {

//    }

//    }
    QBrush brush(Qt::cyan);

    painter.setPen(pen);
    painter.setBrush(brush);

    for (auto &f: _figs)
        f->paint(painter);
}
