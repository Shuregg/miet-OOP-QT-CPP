#ifndef MYFIGURES_H
#define MYFIGURES_H

#include <QWidget>

#include "figure.h"

class MyFigures : public QWidget
{
    Q_OBJECT
public:
    explicit MyFigures(QWidget *parent = nullptr);
    ~MyFigures();

    void setFigures(std::list<Figure*> &&figs) {
        _figs = std::move(figs);
    };

protected:
    virtual void paintEvent(QPaintEvent *event) override;

signals:

private:
    std::list<Figure*> _figs;
};

#endif // MYFIGURES_H
