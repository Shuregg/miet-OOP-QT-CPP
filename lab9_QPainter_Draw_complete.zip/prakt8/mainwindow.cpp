#include <QDebug>

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "figure.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    std::list<Figure*> figs;

    // unique_ptr
    // shared_ptr

    figs.push_back(new Triangle({QPoint(40, 40), QPoint(80, 40), QPoint(60, 60)}));

    figs.push_back(new Triangle({QPoint(200, 240), QPoint(250, 270), QPoint(220, 290)}));

    figs.push_back(new Quad({QPoint(350, 350), QPoint(400, 350), QPoint(350, 400), QPoint(400, 400)}));

    figs.push_back(new Quad({QPoint(550, 150), QPoint(550, 100), QPoint(600, 50), QPoint(600, 100)}));

    figs.push_back(new Rectangle({QPoint(550/2, 150), QPoint(550/2, 100), QPoint(600/2, 100), QPoint(600/2, 150)}));

    figs.push_back(new Rectangle({QPoint(450/2, 15), QPoint(450/2, 3), QPoint(500/2, 15), QPoint(500/2, 15)}));

//    figs.push_back(new Quad({QPoint(rand() % 800, rand() % 800), QPoint(rand() % 800, rand() % 800), QPoint(rand() % 800, rand() % 800), QPoint(rand() % 800, rand() % 800)}));
//    for(int i = 0; i < 500; i++) {
//        figs.push_back(new Quad({QPoint(rand() % 800, rand() % 800), QPoint(rand() % 800, rand() % 800), QPoint(rand() % 800, rand() % 800), QPoint(rand() % 800, rand() % 800)}));
//    }

    ui->widget->setFigures(std::move(figs));
}

MainWindow::~MainWindow()
{

}

