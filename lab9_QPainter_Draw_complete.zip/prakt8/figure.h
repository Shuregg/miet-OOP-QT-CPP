#ifndef FIGURE_H
#define FIGURE_H

#include <array>
#include <QPoint>
#include <QPainter>

class Figure
{
public:
    Figure(const QPoint &ref) : _ref(ref) {};
    virtual void paint(QPainter &painter) = 0;

protected:
    QPoint _ref;
};

template<size_t N>
class Polygon : public Figure {
public:
    Polygon(const std::array<QPoint, N> &verts) : Figure(verts[0]), _verts(verts) {};
    virtual void paint(QPainter &painter) override {
        for (size_t i = 0; i < N; ++i)
            painter.drawLine(_verts[i], _verts[(i + 1) % N]);
    };

private:
    std::array<QPoint, N> _verts;
};

class Rectangle : public Figure{
public:
    Rectangle(const std::array<QPoint, 4> &verts) : Figure(verts[0]), _verts(verts) {};
    virtual void paint(QPainter &painter) override {

        int width, height;
        int x, y;



        int min_x = RAND_MAX;
        int max_x = -RAND_MAX;
        int min_y = RAND_MAX;
        int max_y = - RAND_MAX;
        for(size_t i = 0; i < _verts.size(); i++) {
            if(_verts[i].x() < min_x) {
                min_x = _verts[i].x();
            }
            if(_verts[i].x() > max_x) {
                max_x = _verts[i].x();
            }
            if(_verts[i].y() < min_y) {
                min_y = _verts[i].y();
            }
            if(_verts[i].y() > max_y) {
                max_y = _verts[i].y();
            }


        }
        width = abs(max_x - min_x);
        height = abs(max_y - min_y);
        x = min_x;
        y = min_y;

        painter.drawRect(x, y, width, height);
    }
private:
    std::array<QPoint, 4> _verts;
};

typedef Polygon<3> Triangle;
typedef Polygon<4> Quad;
#endif // FIGURE_H
