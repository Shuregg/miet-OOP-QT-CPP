#include "mywidget.h"
#include "figure.h"
#include <QPainter>
#include <QMouseEvent>
#include <QDebug>

//bool firstDraw = 1;

QColor randomColorRGBA () {

    int R, G, B, ALPHA;
    R = rand() % 256;
    G = rand() % 256;
    B = rand() % 256;
    ALPHA = rand() % 256;

    QColor color(R, G, B, ALPHA);
    return color;
}

MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{
    setMouseTracking(true);
    // создаем фигуры и добавляем их в вектор
    figures.push_back(std::make_shared<Rectangle>(rand()% 500, rand()% 500, rand()% 100, rand()% 100, randomColorRGBA()));
    figures.push_back(std::make_shared<Circle>(rand()% 500, rand()% 500, rand()% 100, randomColorRGBA()));

}


void MyWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event)

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);


    // рисуем все фигуры из вектора
//    if(firstDraw) {

//        firstDraw = 0;
//    } else {
//        for (const auto& figure : figures) {
//            figure->draw(painter);
//        }
//    }
    for (const auto& figure : figures) {

        //QColor rgba = randomColorRGBA();
        figure->draw(painter, figure->color);
    }


    //Если курсор наведен на фигуру,
    if(pointerFigureIndex != -1) {
        auto pointerFigure = figures[pointerFigureIndex].get();

        QColor brushColor = randomColorRGBA();
        QColor penColor = randomColorRGBA();

        painter.setBrush(QBrush(brushColor));
        painter.setPen(QPen(penColor));
        pointerFigure->draw(painter, brushColor);
        //update();
    }
    // если какая-то фигура выбрана
    if (selectedFigureIndex != -1) {
        auto selectedFigure = figures[selectedFigureIndex].get();

        std::vector<int> info_vec = selectedFigure->info();
         std::cout<<std::endl<<std::endl;
        for(int i = 0; i < info_vec.size(); i++) {
           std::cout<<info_vec[i]<<std::endl;
        }
    }


    //painter.end();

}

void MyWidget::mousePressEvent(QMouseEvent *event)
{
    int count{0};
    // ищем фигуру, на которую кликнули
    for (int i = 0; i < figures.size(); i++) {

        if (figures[i]->contains(event->pos())) {

            selectedFigureIndex = i;
            update();
            break;
        } else {
            count++;
        }
    }
    if(count == figures.size()) {
        selectedFigureIndex = -1;
    }
}

void MyWidget::mouseMoveEvent(QMouseEvent *event)
{
    int count{0};
    for(int i = 0; i < figures.size(); i++) {
        if(figures[i]->contains(event->pos())) {

            pointerFigureIndex = i;

            update();
            break;
        }
        else {
            count++;
        }
    }
    if(count == figures.size()) {
        pointerFigureIndex = -1;
    }
}
