#ifndef FIGURE_H
#define FIGURE_H

#include <QPainter>


class Figure
{
public:
    virtual ~Figure() {}
    virtual void draw(QPainter& painter, QColor color) const = 0;
    virtual bool contains(const QPoint& point) const = 0;
    virtual void move(const QPoint& point) = 0;
    virtual std::vector<int> info() = 0;
    int color;

    //void setColor(QColor newColor);
};

class Rectangle : public Figure
{
public:

    Rectangle(int x, int y, int width, int height, QColor color);
    void draw(QPainter& painter, QColor color) const override;
    bool contains(const QPoint& point) const override;
    void move(const QPoint& point) override;

    std::vector<int> info() override;


    QRect rect;
    QColor color;
    int x;
    int y;

};

class Circle : public Figure
{
public:
    int x;
    int y;
    Circle(int x, int y, int radius, QColor color);
    void draw(QPainter& painter, QColor color) const override;
    bool contains(const QPoint& point) const override;
    void move(const QPoint& point) override;

     std::vector<int> info() override;

public:
    QPoint center;
    int radius;
    QColor color;
};

#endif // FIGURE_H
