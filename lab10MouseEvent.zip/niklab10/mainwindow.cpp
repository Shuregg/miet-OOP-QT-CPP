#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    ui->statusbar->showMessage("Hello", 10000);
    QString text = {"X pos: \nY pos: "};
    ui->textBrowser->setText(text);
    //std::list<Figure> figures;

   // figures.push_back(new Rectangle(15, 20, 50, 75));
}

MainWindow::~MainWindow()
{
    delete ui;
}

