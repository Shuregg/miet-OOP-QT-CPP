#include "figure.h"
#include <QPainter>

Rectangle::Rectangle(int x, int y, int width, int height, QColor color)
    : rect(x, y, width, height), color(color)
{
}

void Rectangle::draw(QPainter& painter, QColor color) const
{
    painter.setBrush(QBrush(color));
    painter.setPen(QPen(Qt::black));
    painter.drawRect(rect);
}

bool Rectangle::contains(const QPoint& point) const
{
    return rect.contains(point);
}

void Rectangle::move(const QPoint& point)
{
    rect.moveCenter(point);
}

std::vector<int> Rectangle::info() {
    std::vector<int> figureInfo;
    figureInfo.push_back(this->rect.x());
    figureInfo.push_back(this->rect.y());
    figureInfo.push_back(this->rect.width());
    figureInfo.push_back(this->rect.height());

    return figureInfo;
}
//////////////////////////////////////////////////////
Circle::Circle(int x, int y, int radius, QColor color)
    : center(x, y), radius(radius), color(color)
{
}

void Circle::draw(QPainter& painter, QColor color) const
{
    painter.setBrush(QBrush(color));
    painter.setPen(QPen(Qt::black));
    painter.drawEllipse(center, radius, radius);
}

bool Circle::contains(const QPoint& point) const
{
    return (point - center).manhattanLength() <= radius;
}

void Circle::move(const QPoint& point)
{
    center = point;
}

std::vector<int> Circle::info() {
        std::vector<int> figureInfo;
        figureInfo.push_back(center.x());
        figureInfo.push_back(center.y());

        figureInfo.push_back(radius);

        return figureInfo;
}

//void Figure::setColor(QColor newColor) {

//}
