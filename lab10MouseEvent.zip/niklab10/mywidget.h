#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
#include <QVector>
#include <memory>
#include <time.h>
#include <iostream>

class Figure;

class MyWidget : public QWidget
{
    Q_OBJECT
public:
    explicit MyWidget(QWidget *parent = nullptr);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;


private:
    QVector<std::shared_ptr<Figure>> figures;
    int selectedFigureIndex = -1;
    int pointerFigureIndex = -1;
};

#endif // MYWIDGET_H
