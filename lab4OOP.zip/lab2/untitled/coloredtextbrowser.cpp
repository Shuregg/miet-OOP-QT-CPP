#include "coloredtextbrowser.h"

//ColoredTextBrowser::ColoredTextBrowser()
//{

//}
void ColoredTextBrowser :: colorTheLine(const QString& str, const QColor& newColor) {
    QColor oldColor = textColor();

    setTextColor(newColor);
    append(str);
    setTextColor(oldColor);
}
