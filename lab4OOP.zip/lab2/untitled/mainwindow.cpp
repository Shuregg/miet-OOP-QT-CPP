#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "csvreader.h"
#include "csvwritter.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //ColoredTextBrowser textBrowser = new ColoredTextBrowser(this); //////////////////////////////////////////////TODO????????

    // Open fstream
    //populate vector<Serials>

    CsvReader reader("serials.csv");
    if(reader.is_open()) {
        serials = reader.readAll();
    } else {
        ui->textResults->colorTheLine("Error opening the file!", Qt::red);
    }

}

MainWindow::~MainWindow()
{

    delete ui;
}

void MainWindow::search()
{
    int notFoundCounter = 0;
    ui->textResults->clear();
   // ui->editSearch->clear();
   // ui->textResults->append(ui->editSearch->text()); //example

    //search vector<Serials>
    for(const auto& s: serials) //constant link
    {

        if(QString::fromStdString(s.name).contains(ui->editSearch->text())) {
            ui->textResults->append(QString("%1").arg(s.id) +"    "+ QString::fromStdString(s.name) +"    " + QString("%1").arg(s.year) +"    "+ QString::fromStdString(s.genre));
        } else {
            notFoundCounter++;
        }
    }
    if(notFoundCounter == serials.size()) {
            ui->textResults->colorTheLine("Serial not found.", Qt::darkCyan);
}
}

void MainWindow::addSerial(){
   // ColoredTextBrowser textBrowser = new ColoredTextBrowser(this);
    Serial newSerial;
    int counter = 0;

    ui->textResults->clear();

    newSerial.id = serials.size();                                  //ID

    if(ui->lineEditName->text().toStdString() != "") {              //NAME
        newSerial.name = ui->lineEditName->text().toStdString();
        counter+=1;
  }
 ui->lineEditName->clear();

    if(ui->lineEditYear->text().toStdString() != ""){                    //YEAR
        newSerial.year = ui->lineEditYear->text().toInt();
        counter+=1;
    }

    ui->lineEditYear->clear();

    if(ui->lineEditGenre->text().toStdString() != "") {              //NAME
        newSerial.genre = ui->lineEditGenre->text().toStdString();
        counter+=1;
    }
     ui->lineEditGenre->clear();

     if(counter == 3) {
         serials.push_back(newSerial);
         CsvWritter writer("serials.csv");
         if(writer.isOpen()) {
             writer.writeAll(serials);
         } else {
             ui->textResults->colorTheLine("Error opening the file. (addSerial in MainWindow)", Qt::red);
         }
     } else {
         ui->textResults->colorTheLine("Please, fill in all the input fields to add.", Qt::darkYellow);
     }

}

