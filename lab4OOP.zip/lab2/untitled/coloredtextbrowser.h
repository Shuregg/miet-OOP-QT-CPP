#ifndef COLOREDTEXTBROWSER_H
#define COLOREDTEXTBROWSER_H

#include <QTextBrowser>

class ColoredTextBrowser : public QTextBrowser
{
public:
   ColoredTextBrowser(QWidget *parent = nullptr) : QTextBrowser(parent) {

   }

    void colorTheLine(const QString& str, const QColor& newColor);
};

#endif // COLOREDTEXTBROWSER_H
