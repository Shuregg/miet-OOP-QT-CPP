#ifndef CSVREADER_H
#define CSVREADER_H

#include <string>
#include <vector>
#include<fstream>
#include<serial.h>

class CsvReader
{
private:
    std::ifstream fin;
public:
    CsvReader(const std::string& fname);
    bool is_open() const; //не меняет содержимое самого класса
    std::vector<Serial> readAll();
};

#endif // CSVREADER_H
