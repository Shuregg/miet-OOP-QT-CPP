/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "coloredtextbrowser.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLineEdit *editSearch;
    QPushButton *buttonSearch;
    ColoredTextBrowser *textResults;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *labelAddElement;
    QLineEdit *lineEditName;
    QLineEdit *lineEditYear;
    QLineEdit *lineEditGenre;
    QPushButton *ButtonAddElement;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(977, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        editSearch = new QLineEdit(centralwidget);
        editSearch->setObjectName(QString::fromUtf8("editSearch"));

        horizontalLayout->addWidget(editSearch);

        buttonSearch = new QPushButton(centralwidget);
        buttonSearch->setObjectName(QString::fromUtf8("buttonSearch"));

        horizontalLayout->addWidget(buttonSearch);


        verticalLayout->addLayout(horizontalLayout);

        textResults = new ColoredTextBrowser(centralwidget);
        textResults->setObjectName(QString::fromUtf8("textResults"));

        verticalLayout->addWidget(textResults);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        labelAddElement = new QLabel(centralwidget);
        labelAddElement->setObjectName(QString::fromUtf8("labelAddElement"));

        verticalLayout_2->addWidget(labelAddElement);

        lineEditName = new QLineEdit(centralwidget);
        lineEditName->setObjectName(QString::fromUtf8("lineEditName"));

        verticalLayout_2->addWidget(lineEditName);

        lineEditYear = new QLineEdit(centralwidget);
        lineEditYear->setObjectName(QString::fromUtf8("lineEditYear"));

        verticalLayout_2->addWidget(lineEditYear);

        lineEditGenre = new QLineEdit(centralwidget);
        lineEditGenre->setObjectName(QString::fromUtf8("lineEditGenre"));

        verticalLayout_2->addWidget(lineEditGenre);


        horizontalLayout_3->addLayout(verticalLayout_2);

        ButtonAddElement = new QPushButton(centralwidget);
        ButtonAddElement->setObjectName(QString::fromUtf8("ButtonAddElement"));

        horizontalLayout_3->addWidget(ButtonAddElement);


        verticalLayout->addLayout(horizontalLayout_3);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 977, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(buttonSearch, SIGNAL(clicked()), MainWindow, SLOT(search()));
        QObject::connect(ButtonAddElement, SIGNAL(clicked()), MainWindow, SLOT(addSerial()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "InnikovWindow", nullptr));
        editSearch->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter text here", nullptr));
        buttonSearch->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        labelAddElement->setText(QCoreApplication::translate("MainWindow", "Add new element to database", nullptr));
        lineEditName->setPlaceholderText(QCoreApplication::translate("MainWindow", "Name", nullptr));
        lineEditYear->setPlaceholderText(QCoreApplication::translate("MainWindow", "Year", nullptr));
        lineEditGenre->setPlaceholderText(QCoreApplication::translate("MainWindow", "Genre", nullptr));
        ButtonAddElement->setText(QCoreApplication::translate("MainWindow", "Add", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
