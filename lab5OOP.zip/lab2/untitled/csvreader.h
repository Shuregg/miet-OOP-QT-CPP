#ifndef CSVREADER_H
#define CSVREADER_H


#include"abstractreader.h"

class CsvReader : public AbstractReader
{
private:
    std::ifstream fin;
public:
    CsvReader(const std::string& fname);
    bool is_open() const override; //не меняет содержимое самого класса
    std::vector<Serial> readAll() override;
};

#endif // CSVREADER_H
