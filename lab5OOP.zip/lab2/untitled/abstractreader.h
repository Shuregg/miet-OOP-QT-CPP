#ifndef ABSTRACTREADER_H
#define ABSTRACTREADER_H

#include <string>
#include <vector>
#include <fstream>
#include "serial.h"



class AbstractReader
{
private:
    std::ifstream fin;
public:
    virtual bool is_open() const  = 0;
    virtual std::vector<Serial> readAll() = 0;
    virtual ~AbstractReader() {

    }
};

#endif // ABSTRACTREADER_H
