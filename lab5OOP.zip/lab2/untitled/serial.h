#ifndef SERIAL_H
#define SERIAL_H


#include <string>

struct Serial {
    int id;
    std::string name;
    int year;
    std::string genre;
};

#endif // SERIAL_H
