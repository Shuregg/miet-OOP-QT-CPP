#ifndef JSONREADER_H
#define JSONREADER_H

#include"abstractreader.h"
//#include <nlohmann/json.hpp>
#include "json.hpp"
using json = nlohmann::json;

class JSONReader : public AbstractReader
{
private:
    std::ifstream fin;
public:
    JSONReader(const std::string& fname);
    bool is_open() const override; //не меняет содержимое самого класса
    std::vector<Serial> readAll() override;
};
#endif // JSONREADER_H
