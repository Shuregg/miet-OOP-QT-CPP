#include "jsonreader.h"

JSONReader::JSONReader(const std::string& fname) {
    fin.open(fname);
}

bool JSONReader::is_open() const {
    return fin.is_open();
}

std::vector<Serial> JSONReader::readAll() {
    std::vector<Serial> serials;
    nlohmann::json json;

    fin>>json;

    for(const auto & i: json) {
        Serial serial;

        serial.id = (i["id"]);
        serial.name = (i["name"]);
        serial.year = (i["year"]);
        serial.genre = (i["year"]);

        serials.push_back(serial);
    }
    return serials;
}
