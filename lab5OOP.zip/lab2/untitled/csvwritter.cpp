#include "csvwritter.h"
#include <iostream>
CsvWritter::CsvWritter(const std::string& fname)
{
 fout.open(fname);
}

//void CsvWritter::writeAll(std::vector<Serial> serials) {
//    if(isOpen() == true) {
//        for(int i = 0; i < serials.size(); i++) {
//            fout << serials[i].id << "," << serials[i].name << "," <<serials[i].year << ","<<serials[i].genre << std::endl;
//        }
//    }
//    else {
//        std::cout<<"File is not opened! (writeAll method)"<<std::endl;
//    }
//    fout.close();
//}
void CsvWritter::writeAll(const std::vector<Serial> serials){
    for(int i = 0; i < serials.size()-1; i++){
        Serial s = serials[i];
        fout << s.id << "," << s.name << "," << s.year << "," << s.genre << std::endl;
        }
    fout << serials[serials.size()-1].id << "," << serials[serials.size()-1].name << "," << serials[serials.size()-1].year << "," << serials[serials.size()-1].genre;
}


//void addSerial(int id, std::string& name, int year, std::string& genre, std::vector<Serial> serials) {
//    Serial newSerial = {id, name, year, genre};
//    serials.push_back(newSerial);
//}
