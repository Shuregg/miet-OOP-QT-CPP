#include<fstream>

#include "csvreader.h"

std::vector<std::string> split(const std::string& str, char delim)
{
    std::vector<std::string> tokens;

    if (!str.empty())
    {
        size_t start = 0, end;

       /* for(size_t i = 0; i < str.size(); i++)
        {
            if(str[i] == delim) {
                end = i;
            }
        } */

        do {
            end = str.find(delim, start);
            tokens.push_back(str.substr(start, (end - start)));
            start = end + 1;
        } while (end != std::string::npos);
    }

    return tokens;
}

CsvReader::CsvReader(const std::string& fname)
{
    fin.open(fname);
}

bool CsvReader::is_open() const
{
    return fin.is_open();
}

std::vector<Serial> CsvReader::readAll() {
    std::vector<Serial> serials;

    while (!fin.eof()) {
        std::string str;
        std::getline(fin, str);

        auto tokens = split(str, ',');
        Serial s;
        s.id = std::stoi(tokens[0]);
        s.name = tokens[1];
        s.year = std::stoi(tokens[2]);
        s.genre = tokens[3];
        serials.push_back(s);
    }
    return serials;
}
