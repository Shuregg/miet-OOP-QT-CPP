#ifndef CSVWRITTER_H
#define CSVWRITTER_H

#include <string>
#include <vector>
#include<fstream>
#include "serial.h"

class CsvWritter
{
private:
    std::ofstream fout;
public:
    CsvWritter(const std::string& fname);
    bool isOpen() const {return fout.is_open();}
    void writeAll(std::vector<Serial> serials);
    //void addSerial(int id, std::string& name, int year, std::string& genre);
};

#endif // CSVWRITTER_H
