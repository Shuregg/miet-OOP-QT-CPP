#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "csvreader.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Open fstream
    //populate vector<Serials>

    CsvReader reader("serials.csv");
    if(reader.is_open()) {
        serials = reader.readAll();
    } else {
        ui->textResults->append("No such file");
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::search()
{
    ui->textResults->clear();
   // ui->editSearch->clear();
   // ui->textResults->append(ui->editSearch->text()); //example

    //search vector<Serials>
    for(const auto& s: serials) //constant link
    {

        if(QString::fromStdString(s.name).contains(ui->editSearch->text())) {
            ui->textResults->append(QString("%1").arg(s.id) +"    "+ QString::fromStdString(s.name) +"    " + QString("%1").arg(s.year) +"    "+ QString::fromStdString(s.genre));
        }
    }
}

